# AI Assistance Declaration (draft; student must complete verification details):
# I used ChatGPT (GPT-6, 2026-10-31) to discuss data-cleaning logic and
# draft commented R code. Prompts appear in AI_Prompts_Appendix.md.
# I must personally verify outputs using Sheets, an independent cross-check,
# and a self/peer spot-check before submitting. Final calculations must be mine.
# Student: Nagham Sabouh | Course: BDA400 | Assignment 4
# Actual dataset: OrderID, Product, Quantity, Price, Customer.
# Do not assume CustomerID, Region, or Revenue columns exist.

if (!requireNamespace("dplyr", quietly = TRUE)) {
  stop("Install dplyr first: install.packages('dplyr')")
}
library(dplyr)

input <- "sales_data_dirty.csv"
if (!file.exists(input)) stop("Place sales_data_dirty.csv in the working directory")
raw <- read.csv(input, stringsAsFactors = FALSE, na.strings = c("", "NA"))
needed <- c("OrderID", "Product", "Quantity", "Price", "Customer")
if (!all(needed %in% names(raw))) stop("Unexpected columns in source CSV")

# Audit before cleaning; save a genuine RStudio console log to the text file.
report_quality <- function(df, label) {
  cat("\n===", label, "===\n")
  cat("Rows:", nrow(df), "\n")
  cat("Exact duplicate rows:", sum(duplicated(df)), "\n")
  cat("Missing values by column:\n")
  print(colSums(is.na(df)))
  cat("Missing/blank Product:", sum(is.na(df$Product) | trimws(df$Product) == ""), "\n")
  cat("Missing Quantity:", sum(is.na(df$Quantity)), "\n")
  cat("Quantity <= 0:", sum(!is.na(df$Quantity) & df$Quantity <= 0), "\n")
  cat("Quantity > 100:", sum(!is.na(df$Quantity) & df$Quantity > 100), "\n")
  cat("Products:\n"); print(table(df$Product, useNA = "ifany"))
  cat("Summary:\n"); print(summary(df))
}

sink("before_after_Rstudio_log.txt", split = TRUE)
report_quality(raw, "BEFORE CLEANING")

# Keep only one copy of each completely duplicated source row.
# Standardize text without inventing unknown Product values.
# Drop records with missing Product or Quantity; do not impute quantities.
# Treat 0/negative quantity and 1000 units as unsuitable for this exercise.
# Keep quantity 100 (an observed source category); 100 is not an outlier here.
cleaned <- raw %>%
  distinct() %>%
  mutate(
    Product = trimws(Product),
    Customer = trimws(tolower(Customer)),
    Product = ifelse(is.na(Product) | Product == "", NA_character_, Product)
  ) %>%
  filter(!is.na(Product), !is.na(Customer), Customer != "",
         !is.na(Quantity), is.finite(Quantity),
         Quantity > 0, Quantity <= 100,
         !is.na(Price), is.finite(Price), Price > 0) %>%
  arrange(OrderID)

report_quality(cleaned, "AFTER CLEANING")
cat("Removed rows:", nrow(raw) - nrow(cleaned), "\n")
# Assertions are intended to fail loudly if cleaning conditions are violated.
stopifnot(!anyDuplicated(cleaned),
          !anyNA(cleaned[, needed]),
          all(cleaned$Quantity > 0 & cleaned$Quantity <= 100),
          all(cleaned$Price > 0),
          all(trimws(cleaned$Product) != ""),
          all(cleaned$Customer == tolower(cleaned$Customer)))
cat("Checks passed. Review source rows and selected threshold manually.\n")
sink()

write.csv(cleaned, "sales_data_cleaned.csv", row.names = FALSE, na = "")
cat("Saved sales_data_cleaned.csv and before_after_Rstudio_log.txt\n")
