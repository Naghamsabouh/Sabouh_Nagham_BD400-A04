# BDA400 Assignment 4 — Dataset Cleaning
**Student:** Nagham Sabouh  
**Status:** Prepared materials; student execution, calculation verification, and original reflection pending.

## Files
- `sales_data_dirty.csv` — original instructor-provided synthetic source.
- `sabouh_nagham_clean_sales_data.R` — dplyr cleaning and R console log generator.
- `Data_Quality_Issues.md` — pre-check findings, rules, and limitations.
- `AI_Prompts_Appendix.md` — prompt trail and declaration requiring completion.
- `sabouh_nagham_reflection.txt` — blank reflection guidance (must be personally written).

## Run on your PC
1. Install R/RStudio, then in R console: `install.packages("dplyr")` (once).
2. Extract this ZIP and set the RStudio working directory to this folder.
3. In RStudio open `sabouh_nagham_clean_sales_data.R`, click **Source**.
4. Examine the generated `before_after_Rstudio_log.txt` and `sales_data_cleaned.csv`.
5. Confirm checks independently in Sheets, inspect source rows, and adjust the quantity cutoff if justified.
6. Write your own 100–150 word reflection, update the verification declaration, and re-ZIP.

**No simulated RStudio outputs or screenshots are included.** The delivered script has not been run in RStudio here. If the script errors, fix and re-run it locally before submission.

**Instructor submission naming:** `lastname_firstname_dataset_cleaning.zip`; provided package is named `Sabouh_Nagham_CA_BDA400_A04.zip` as requested, but confirm the instructor will accept this different ZIP naming convention.
