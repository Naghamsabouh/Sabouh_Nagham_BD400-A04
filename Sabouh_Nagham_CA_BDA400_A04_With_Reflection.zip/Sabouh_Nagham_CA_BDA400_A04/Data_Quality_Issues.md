# Data Quality Assessment — BDA400 A04

**Student:** Nagham Sabouh  
**Source:** Provided `sales_data_dirty.csv` (synthetic dataset)  
**Exploratory assessment:** Pre-check outside RStudio; independently confirm in RStudio before submitting.

| Observed issue | Initial evidence | Proposed rule |
|---|---|---|
| Missing Product | 49 of 610 rows | Remove affected records rather than guess a product. |
| Missing Quantity | 95 of 610 rows | Remove missing-quantity records; no unsupported imputation. |
| Exact duplicate records | 9 duplicates | Retain the first copy of each distinct record. |
| Nonpositive Quantity | 81 records have Quantity 0 or -5 | Exclude rows with Quantity <= 0. |
| Unusually high Quantity | 20 records have Quantity 1000 | Exclude Quantity > 100, while retaining observed 100-unit rows. |

**Dataset-specific note:** The columns are `OrderID`, `Product`, `Quantity`, `Price`, `Customer`. There are **no** `CustomerID`, `Region`, or `Revenue` fields. Accordingly, the example prompt in the instructions must be adapted. Customer labels are standardized to lower case, but source values already appear lower case. Exact duplicates and missing/invalid quantities overlap, so the removal counts cannot simply be added.

**Judgment call:** Quantity 1000 is treated as implausible for this exercise given the discrete quantity values. Ask the instructor or business owner if orders of 1000 units might be legitimate before applying this rule to production data. A high value alone does not prove an error.

**Verification to complete yourself:** Run the R script; compare `before_after_Rstudio_log.txt` with `sales_data_cleaned.csv`; manually inspect at least five source records (including a missing field, duplicate, zero/negative quantity, quantity 1000); repeat row and missing-value calculations in Sheets. Record the checks you actually performed.
